<!-- : tuliskan tampilan view web buku anda disini -->
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Manajemen Buku</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-6">
  <div class="max-w-6xl mx-auto bg-white p-6 rounded shadow">
    <!-- Header -->
    <div class="flex justify-between items-center mb-4">
      <h1 class="text-2xl font-bold">Manajemen Buku</h1>
      <button class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">+ Tambah Buku</button>
      <a href="{{ route('buku.create') }}" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">+ Tambah Buku</a>
    </div>

    <!-- Flash Message -->
    @if(session('success'))
    <div class="bg-green-100 text-green-700 p-3 rounded mb-4">{{ session('success') }}</div>
    @endif

    <tbody>
      @foreach($databuku as $buku)
      <tr class="border-t">
        <td class="p-2">{{ $buku->judul }}</td>
        <td class="p-2">{{ $buku->pengarang }}</td>
        <td class="p-2">{{ $buku->tahun }}</td>
        <td class="p-2">{{ $buku->penerbit }}</td>
        <td class="p-2">{{ $buku->kategori }}</td>
        <td class="p-2 space-x-2">
            <a href="{{ route('buku.edit', $buku->id) }}" class="bg-yellow-400 px-3 py-1 rounded text-white hover:bg-yellow-500">Edit</a>
            <form action="{{ route('buku.destroy', $buku->id) }}" method="POST" class="inline">
                @csrf
                @method('DELETE')
                <button type="submit" onclick="return confirm('Yakin ingin menghapus?')" class="bg-red-600 px-3 py-1 rounded text-white hover:bg-red-700">Hapus</button>
            </form>
          </td>
        </tr>
      @endforeach
    </tbody>
    

    <!-- Filter -->
    <div class="flex gap-4 mb-6">
      <input type="text" placeholder="Cari judul buku..." class="w-full border px-3 py-2 rounded">
      <select class="border px-3 py-2 rounded">
        <option>Semua Kategori</option>
        <option>Novel</option>
        <option>Ensiklopedia</option>
        <option>Biografi</option>
        <option>Komik</option>
        <option>Fiksi</option>
        <option>Nonfiksi</option>
        <option>Akademik</option>
        <option>Puisi & Sastra</option>
        <!-- Tambahkan kategori lain sesuai kebutuhan -->
      </select>
    </div>

    <form action="{{ route('buku.store') }}" method="POST">
      @csrf
      <input name="judul" type="text" placeholder="Judul Buku" class="border px-3 py-2 rounded">
      <!-- input lainnya -->
      <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Simpan</button>
    </form>

    <!-- Form Buku -->
    <div class="mb-6">
      <h2 class="text-xl font-semibold mb-2">Form Buku</h2>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <input type="text" placeholder="Judul Buku" class="border px-3 py-2 rounded">
        <input type="text" placeholder="Pengarang" class="border px-3 py-2 rounded">
        <input type="text" placeholder="Tahun Terbit" class="border px-3 py-2 rounded">
        <input type="text" placeholder="Penerbit" class="border px-3 py-2 rounded">
        <input type="text" placeholder="Kategori" class="border px-3 py-2 rounded md:col-span-2">
      </div>
      <button class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Simpan</button>
    </div>

    <!-- Tabel Daftar Buku -->
    <div>
      <h2 class="text-xl font-semibold mb-2">Daftar Buku</h2>
      <div class="overflow-x-auto">
        <table class="w-full text-left border">
          <thead class="bg-gray-200">
            <tr>
              <th class="p-2">JUDUL</th>
              <th class="p-2">PENGARANG</th>
              <th class="p-2">TAHUN</th>
              <th class="p-2">PENERBIT</th>
              <th class="p-2">KATEGORI</th>
              <th class="p-2">AKSI</th>
            </tr>
          </thead>
          <tbody>
            <tr class="border-t">
              <td class="p-2">Laskar Pelangi</td>
              <td class="p-2">Andrea Hirata</td>
              <td class="p-2">2005</td>
              <td class="p-2">Bentang Pustaka</td>
              <td class="p-2">Novel</td>
              <td class="p-2 space-x-2">
                <button class="bg-yellow-400 px-3 py-1 rounded text-white hover:bg-yellow-500">Edit</button>
                <button class="bg-red-600 px-3 py-1 rounded text-white hover:bg-red-700">Hapus</button>
              </td>
            </tr>
            <tr class="border-t">
              <td class="p-2">Negeri 5 Menara</td>
              <td class="p-2">Ahmad Fuadi</td>
              <td class="p-2">2009</td>
              <td class="p-2">Gramedia Pustaka Utama</td>
              <td class="p-2">Fiksi</td>
              <td class="p-2 space-x-2">
                <button class="bg-yellow-400 px-3 py-1 rounded text-white hover:bg-yellow-500">Edit</button>
                <button class="bg-red-600 px-3 py-1 rounded text-white hover:bg-red-700">Hapus</button>
              </td>
            </tr>
            <tr class="border-t">
              <td class="p-2">Filosofi Teras</td>
              <td class="p-2">Henry Manampiring</td>
              <td class="p-2">2018</td>
              <td class="p-2">Kompas Gramedia</td>
              <td class="p-2">Nonfiksi</td>
              <td class="p-2 space-x-2">
                <button class="bg-yellow-400 px-3 py-1 rounded text-white hover:bg-yellow-500">Edit</button>
                <button class="bg-red-600 px-3 py-1 rounded text-white hover:bg-red-700">Hapus</button>
              </td>
            </tr>
            <tr class="border-t">
                <td class="p-2">Aku</td>
                <td class="p-2">Sjuman Djaya</td>
                <td class="p-2">1981</td>
                <td class="p-2">Pustaka Jaya</td>
                <td class="p-2">Puisi & Sastra</td>
                <td class="p-2 space-x-2">
                  <button class="bg-yellow-400 px-3 py-1 rounded text-white hover:bg-yellow-500">Edit</button>
                  <button class="bg-red-600 px-3 py-1 rounded text-white hover:bg-red-700">Hapus</button>
                </td>
            </tr>
            <tr class="border-t">
              <td class="p-2">9 Summers 10 Autumns</td>
              <td class="p-2">Iwan Setyawan</td>
              <td class="p-2">2011</td>
              <td class="p-2">Gramedia Pustaka Umum</td>
              <td class="p-2">Biografi</td>
              <td class="p-2 space-x-2">
                <button class="bg-yellow-400 px-3 py-1 rounded text-white hover:bg-yellow-500">Edit</button>
                <button class="bg-red-600 px-3 py-1 rounded text-white hover:bg-red-700">Hapus</button>
              </td>
            <!-- Tambahkan baris buku lain di sini -->
          </tbody>
        </table>
      </div>
    </div>

    <!-- Pagination -->
    <div class="flex justify-between items-center mt-4 text-sm text-gray-600">
      <span>Menampilkan 1 - 10 dari 100 buku</span>
      <div class="flex gap-1">
        <button class="px-2 py-1 border rounded">&laquo;</button>
        <button class="px-3 py-1 border rounded bg-blue-600 text-white">1</button>
        <button class="px-3 py-1 border rounded">2</button>
        <button class="px-3 py-1 border rounded">3</button>
        <span class="px-2 py-1">...</span>
        <button class="px-3 py-1 border rounded">10</button>
        <button class="px-2 py-1 border rounded">&raquo;</button>
      </div>
    </div>
  </div>
</body>
</html>

